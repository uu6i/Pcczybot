# AyaPy 3.0 — Android Python IDE

AyaPy is an Android Studio/Gradle project built with Kotlin, Jetpack Compose and Chaquopy's embedded CPython runtime. The project targets ARM64 Android devices.

## Build the APK from your phone

1. Create a GitHub repository and upload the **contents** of this project folder.
2. Open the repository's **Actions** tab.
3. Select **Build AyaPy Android APK** and tap **Run workflow**.
4. Wait for the run to finish successfully.
5. Open the run's Artifacts section and download **AyaPy-3.0-Android-APK**.
6. Extract the artifact ZIP and install `AyaPy-3.0-arm64-debug.apk`. Android may ask you to allow installs from the browser or file manager.

The workflow installs/configures JDK 17, Android SDK and Gradle 8.13, validates the Python runner, and builds an ARM64 debug APK. The source ZIP is not itself an APK. This environment does not have the Android SDK/Gradle installation needed to execute and verify that APK build locally.

## Implemented in this source

- Embedded CPython 3.13 for ARM64 Android through Chaquopy.
- Compose editor with document open/save, run-current-buffer, output panel and monospace editing.
- Persistent Python execution namespace for editor runs and `python -c`.
- App-private workspace and file commands: `pwd`, `ls`, `cd`, `mkdir`, `touch`, `cat`, `cp`, `mv`, `rm`, `tree`, `find`.
- Python syntax validation with `check FILE`.
- Package metadata inspection with `pip list` and `pip show`.
- HTTP API requests: `http GET|POST|PUT|PATCH|DELETE|HEAD URL [JSON]`.
- JSON validation/pretty-print (`json-check FILE`, `json FILE`) and XML pretty-print (`xml FILE`).
- SQLite query helper (`sqlite FILE "SQL"`) and ZIP create/extract commands.
- Environment and runtime diagnostics (`sysinfo`, `env`, `sys.path`).
- Local audio/direct audio URL playback through an Android foreground media service with notification pause/resume/stop controls.
- Dark/light/system appearance selection and glass-style Compose interface.
- GitHub Actions workflow for building the installable ARM64 debug APK.

## Important limitations — please read

This is a working early Android IDE foundation, **not yet a complete Pydroid + Termux replacement**. The following are not implemented in this source and are not presented as working features:

- A complete rootless Linux distribution, bash, `apt`/`pkg`, or arbitrary shell commands.
- Runtime `pip install`/`uninstall`, multiple Python interpreters, or virtual environments. Chaquopy dependencies must be compatible with Android and bundled at APK build time in `app/build.gradle.kts`.
- Full multi-file project explorer, multi-tab editor, syntax highlighting, language-server autocomplete, minimap, folding, or graphical debugger.
- Git UI, Jupyter notebook UI, WebSocket tester, local server manager, scheduled scripts, offline documentation, plugin marketplace, or AI coding assistant.
- Integrated Black/Ruff/Mypy tooling or YouTube background audio. YouTube audio is not extracted; playback must use an officially supported player route.

Android native wheels are not interchangeable with desktop Linux/Windows wheels. Even with a rootless Linux userspace, Android storage, process lifecycle, ABI and background-execution constraints require explicit integration. These features need additional engineering and testing; they cannot honestly be claimed complete merely by adding menu entries.

## Test status

The Python runner was syntax-checked and smoke-tested in the authoring environment for persistent execution, workspace tree/search, JSON formatting, syntax checking and SQLite. These tests do **not** prove Android/Chaquopy compatibility. No APK build has been executed in this environment because Android SDK and Gradle are unavailable. The included GitHub Actions run is the required Android build verification. If it fails, share the full failed job log so the exact build issue can be fixed.

## Project structure

- `app/src/main/java/com/ayaansh/ayapy/MainActivity.kt` — Compose app and terminal bridge
- `app/src/main/java/com/ayaansh/ayapy/MusicService.kt` — background audio service
- `app/src/main/python/runner.py` — embedded Python runtime and workspace tools
- `.github/workflows/build-apk.yml` — cloud Android APK build
