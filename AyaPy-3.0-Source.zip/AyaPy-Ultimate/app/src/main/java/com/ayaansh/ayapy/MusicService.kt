package com.ayaansh.ayapy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class MusicService : Service() {
    private var player: MediaPlayer? = null
    private val channelId = "ayapy_music"

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val source = intent.getStringExtra(EXTRA_SOURCE)
                if (!source.isNullOrBlank()) play(source)
            }
            ACTION_PAUSE -> {
                if (player?.isPlaying == true) player?.pause()
                updateNotification("Paused")
            }
            ACTION_RESUME -> {
                player?.start()
                updateNotification("Playing")
            }
            ACTION_STOP -> {
                player?.release()
                player = null
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun play(source: String) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                if (source.startsWith("content://")) setDataSource(this@MusicService, Uri.parse(source))
                else setDataSource(source)
                setOnPreparedListener {
                    it.start()
                    updateNotification("Playing")
                }
                setOnCompletionListener { updateNotification("Finished") }
                setOnErrorListener { _, what, extra ->
                    updateNotification("Playback error ($what/$extra)")
                    true
                }
                prepareAsync()
            }
            startForeground(NOTIFICATION_ID, notification("Preparing"))
        } catch (e: Exception) {
            updateNotification("Unable to play: ${e.message ?: "unknown error"}")
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "AyaPy music", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(status: String): Notification {
        val pause = PendingIntent.getService(
            this, 1, Intent(this, MusicService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val resume = PendingIntent.getService(
            this, 2, Intent(this, MusicService::class.java).setAction(ACTION_RESUME),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 3, Intent(this, MusicService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("AyaPy Music")
            .setContentText(status)
            .setOngoing(status == "Playing" || status == "Preparing")
            .addAction(android.R.drawable.ic_media_pause, "Pause", pause)
            .addAction(android.R.drawable.ic_media_play, "Resume", resume)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
            .build()
    }

    private fun updateNotification(status: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(status))
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_PLAY = "com.ayaansh.ayapy.PLAY"
        const val ACTION_PAUSE = "com.ayaansh.ayapy.PAUSE"
        const val ACTION_RESUME = "com.ayaansh.ayapy.RESUME"
        const val ACTION_STOP = "com.ayaansh.ayapy.STOP"
        const val EXTRA_SOURCE = "source"
        private const val CHANNEL_ID = "ayapy_music"
        private const val NOTIFICATION_ID = 7021
    }
}
