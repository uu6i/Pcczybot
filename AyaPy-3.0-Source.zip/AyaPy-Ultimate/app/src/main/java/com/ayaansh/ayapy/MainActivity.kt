package com.ayaansh.ayapy

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

private enum class Screen { HOME, EDITOR, TERMINAL, PROJECTS, PACKAGES, MUSIC, TOOLS, SETTINGS }
private enum class ThemeChoice { DARK, LIGHT, SYSTEM }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        setContent { AyaPyApp() }
    }
}

@Composable
private fun AyaPyApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf(Screen.HOME) }
    var themeChoice by remember { mutableStateOf(ThemeChoice.DARK) }
    var code by remember { mutableStateOf("print('Hello from AyaPy!')\nprint('Python 3.13 is running on Android.')") }
    var output by remember { mutableStateOf("AyaPy terminal ready.\nType help to see commands.\n") }
    var command by remember { mutableStateOf("") }
    var fileName by remember { mutableStateOf("main.py") }
    var busy by remember { mutableStateOf(false) }
    var packageInfo by remember { mutableStateOf("Packages are inspected from the embedded Python environment.") }
    var musicSource by remember { mutableStateOf("") }
    val dark = themeChoice == ThemeChoice.DARK || (themeChoice == ThemeChoice.SYSTEM &&
        (context.resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES)
    val bg = if (dark) Color(0xFF080B15) else Color(0xFFF1F4FA)
    val panel = if (dark) Color(0xB8202B49) else Color(0xDFFFFFFF)
    val edge = if (dark) Color(0x557D91C7) else Color(0x668A9BB9)
    val fg = if (dark) Color(0xFFF3F5FF) else Color(0xFF172033)
    val muted = if (dark) Color(0xFFAAB5D0) else Color(0xFF5E6B83)

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    code = input.bufferedReader().readText()
                }
                fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "opened.py"
                screen = Screen.EDITOR
            }.onFailure { output = "Open failed: ${it.message}" }
        }
    }
    val saveFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/x-python")) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(code.toByteArray()) }
                output = "Saved $fileName successfully."
            }.onFailure { output = "Save failed: ${it.message}" }
        }
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            musicSource = uri.toString()
            val intent = Intent(context, MusicService::class.java).setAction(MusicService.ACTION_PLAY)
                .putExtra(MusicService.EXTRA_SOURCE, musicSource)
            if (android.os.Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent) else context.startService(intent)
        }
    }

    Box(Modifier.fillMaxSize().background(
        Brush.linearGradient(if (dark) listOf(Color(0xFF080B15), Color(0xFF17264A), Color(0xFF160F2A)) else listOf(Color(0xFFF5F7FC), Color(0xFFE3EAF8), Color(0xFFF4F0FA)))
    )) {
        Box(Modifier.size(230.dp).offset(x = 180.dp, y = 80.dp).blur(95.dp).background(if (dark) Color(0x553B68C8) else Color(0x557DA5E8), CircleShape))
        Column(Modifier.fillMaxSize().padding(horizontal = 15.dp, vertical = 12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.clickable { screen = Screen.HOME }) {
                    Text("AyaPy", color = fg, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("Android Python IDE · CPython 3.13", color = muted, fontSize = 11.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Surface(color = if (dark) Color(0x553D6B58) else Color(0xFFE0F5E8), shape = CircleShape) {
                        Text("● READY", color = Color(0xFF258B55), fontSize = 10.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                    }
                    IconButton(onClick = { themeChoice = when (themeChoice) { ThemeChoice.DARK -> ThemeChoice.LIGHT; ThemeChoice.LIGHT -> ThemeChoice.SYSTEM; ThemeChoice.SYSTEM -> ThemeChoice.DARK } }) {
                        Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "Change theme", tint = fg)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            when (screen) {
                Screen.HOME -> HomeScreen(fg, muted, panel, edge, onOpen = { screen = it }, onNew = { code = ""; fileName = "untitled.py"; screen = Screen.EDITOR }, onOpenFile = { openFile.launch(arrayOf("text/*", "application/octet-stream")) })
                Screen.EDITOR -> EditorScreen(code, { code = it }, fileName, { saveFile.launch(fileName) }, { openFile.launch(arrayOf("text/*", "application/octet-stream")) }, output, busy, {
                    busy = true
                    val current = code
                    // Execute off the UI thread. The Python runtime is embedded in this APK.
                    scope.launch {
                        output = withContext(Dispatchers.IO) {
                            try { Python.getInstance().getModule("runner").callAttr("execute", current).toString() }
                            catch (e: Exception) { "Runtime error: ${e.message}" }
                        }
                        busy = false
                    }
                }, fg, muted, panel, edge, { screen = Screen.TERMINAL })
                Screen.TERMINAL -> TerminalScreen(output, command, { command = it }, { cmd ->
                    if (cmd.trim() == "clear") { output = ""; command = ""; return@TerminalScreen }
                    busy = true
                    scope.launch {
                        output += "\n$ $cmd\n"
                        val result = withContext(Dispatchers.IO) { executeCommand(cmd, fileName, code) }
                        output += result + "\n"
                        busy = false
                        command = ""
                    }
                }, busy, fg, muted, panel, edge)
                Screen.PROJECTS -> ProjectsScreen(fg, muted, panel, edge, { openFile.launch(arrayOf("text/*", "application/octet-stream")) }, { saveFile.launch(fileName) })
                Screen.PACKAGES -> PackagesScreen(packageInfo, fg, muted, panel, edge, {
                    busy = true
                    scope.launch {
                        packageInfo = withContext(Dispatchers.IO) {
                            try { Python.getInstance().getModule("runner").callAttr("package_list").toString() }
                            catch (e: Exception) { "Could not read packages: ${e.message}" }
                        }
                        busy = false
                    }
                })
                Screen.MUSIC -> MusicScreen(musicSource, fg, muted, panel, edge, { pickAudio.launch(arrayOf("audio/*")) }, {
                    context.startService(Intent(context, MusicService::class.java).setAction(MusicService.ACTION_PAUSE))
                }, {
                    context.startService(Intent(context, MusicService::class.java).setAction(MusicService.ACTION_RESUME))
                }, {
                    context.startService(Intent(context, MusicService::class.java).setAction(MusicService.ACTION_STOP))
                    musicSource = ""
                })
                Screen.TOOLS -> ToolsScreen(fg, muted, panel, edge)
                Screen.SETTINGS -> SettingsScreen(themeChoice, { themeChoice = it }, fg, muted, panel, edge)
            }
            Spacer(Modifier.height(10.dp))
            NavigationBar(screen, fg, muted, panel, edge) { screen = it }
        }
    }
}

private suspend fun executeCommand(command: String, fileName: String, currentCode: String): String {
    val c = command.trim()
    if (c.isEmpty()) return ""
    if (c == "clear") return ""
    if (c == "python --version" || c == "python -V") {
        return Python.getInstance().getModule("sys").get("version").toString()
    }
    if (c == "pip list" || c == "python -m pip list") {
        return Python.getInstance().getModule("runner").callAttr("package_list").toString()
    }
    if (c.startsWith("pip show ") || c.startsWith("python -m pip show ")) {
        return Python.getInstance().getModule("runner").callAttr("package_show", c.substringAfter("show ").trim()).toString()
    }
    if (c.startsWith("pip install ") || c.startsWith("python -m pip install ")) {
        val pkg = c.substringAfter("install ").trim()
        return "Cannot install '$pkg' dynamically in this Chaquopy runtime. Add an Android-compatible package to chaquopy.defaultConfig.pip in app/build.gradle.kts and rebuild. Standard desktop PyPI wheels are not generally Android-compatible."
    }
    if (c.startsWith("pip uninstall ")) {
        return "Dynamic pip uninstall is not supported by the embedded Chaquopy environment. Remove build-time package configuration and rebuild."
    }
    if (c.startsWith("python -c ")) {
        val source = c.removePrefix("python -c ").trim().removeSurrounding("\"").removeSurrounding("'")
        return Python.getInstance().getModule("runner").callAttr("execute", source).toString()
    }
    if (c == "python main.py" || c == "python $fileName") {
        return Python.getInstance().getModule("runner").callAttr("execute", currentCode, true).toString()
    }
    if (c.startsWith("python ")) {
        return Python.getInstance().getModule("runner").callAttr("run_file", c.removePrefix("python ").trim()).toString()
    }
    return Python.getInstance().getModule("runner").callAttr("dispatch", c).toString()
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, panel: Color, edge: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(23.dp)).background(panel).border(1.dp, edge, RoundedCornerShape(23.dp)).padding(15.dp), content = content)
}

@Composable
private fun MenuItem(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, desc: String, fg: Color, muted: Color, panel: Color, edge: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(panel).border(1.dp, edge, RoundedCornerShape(18.dp)).clickable { onClick() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Color(0x557C8FB8)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color(0xFFD5E0FF)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Text(desc, color = muted, fontSize = 10.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = muted)
    }
}

@Composable
private fun ColumnScope.HomeScreen(fg: Color, muted: Color, panel: Color, edge: Color, onOpen: (Screen) -> Unit, onNew: () -> Unit, onOpenFile: () -> Unit) {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("Welcome back.", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Python 3.13 · ARM64 runtime", color = muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onNew) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("New file") }
                OutlinedButton(onClick = onOpenFile) { Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(5.dp)); Text("Open") }
            }
        }
        Text("DEVELOP", color = muted, fontSize = 10.sp, letterSpacing = 2.sp)
        MenuItem(Icons.Default.Code, "Code Studio", "Editor, run and save Python files", fg, muted, panel, edge) { onOpen(Screen.EDITOR) }
        MenuItem(Icons.Default.Terminal, "Terminal", "Python console, workspace, API requests, JSON/XML, SQLite and ZIP tools", fg, muted, panel, edge) { onOpen(Screen.TERMINAL) }
        MenuItem(Icons.Default.Folder, "Projects", "Open and export Python files", fg, muted, panel, edge) { onOpen(Screen.PROJECTS) }
        Text("TOOLS", color = muted, fontSize = 10.sp, letterSpacing = 2.sp)
        MenuItem(Icons.Default.Inventory2, "Package Hub", "Inspect embedded Python package metadata", fg, muted, panel, edge) { onOpen(Screen.PACKAGES) }
        MenuItem(Icons.Default.MusicNote, "Music Studio", "Background local audio and direct streams", fg, muted, panel, edge) { onOpen(Screen.MUSIC) }
        MenuItem(Icons.Default.Build, "Developer tools", "Git, debugger, notebooks and more roadmap", fg, muted, panel, edge) { onOpen(Screen.TOOLS) }
        MenuItem(Icons.Default.Settings, "Settings", "Themes and app configuration", fg, muted, panel, edge) { onOpen(Screen.SETTINGS) }
    }
}

@Composable
private fun ColumnScope.EditorScreen(code: String, onCode: (String) -> Unit, fileName: String, onSave: () -> Unit, onOpen: () -> Unit, output: String, busy: Boolean, onRun: () -> Unit, fg: Color, muted: Color, panel: Color, edge: Color, onTerminal: () -> Unit) {
    Column(Modifier.weight(1f)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text(fileName, color = fg, fontWeight = FontWeight.Bold); Text("Python source", color = muted, fontSize = 10.sp) }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(onClick = onOpen) { Icon(Icons.Default.FolderOpen, null, tint = fg) }
                IconButton(onClick = onSave) { Icon(Icons.Default.Save, null, tint = fg) }
                Button(onClick = onRun, enabled = !busy, contentPadding = PaddingValues(horizontal = 12.dp)) { Icon(Icons.Default.PlayArrow, null); Text(if (busy) "Running" else "Run") }
            }
        }
        Spacer(Modifier.height(8.dp))
        GlassPanel(Modifier.weight(1f).fillMaxWidth(), panel, edge) {
            BasicTextField(
                value = code, onValueChange = onCode, modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                textStyle = TextStyle(color = fg, fontSize = 13.sp, lineHeight = 21.sp, fontFamily = FontFamily.Monospace),
                cursorBrush = SolidColor(Color(0xFF83AFFF)),
                decorationBox = { inner -> Box { if (code.isEmpty()) Text("# Write Python here", color = muted); inner() } }
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("OUTPUT", color = muted, fontSize = 10.sp, letterSpacing = 2.sp)
            TextButton(onClick = onTerminal) { Text("Open terminal") }
        }
        GlassPanel(Modifier.fillMaxWidth().heightIn(min = 90.dp, max = 155.dp), panel, edge) {
            Text(output, color = Color(0xFF8FD6A5), fontSize = 11.sp, lineHeight = 17.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun ColumnScope.TerminalScreen(output: String, command: String, onCommand: (String) -> Unit, onExecute: (String) -> Unit, busy: Boolean, fg: Color, muted: Color, panel: Color, edge: Color) {
    Column(Modifier.weight(1f)) {
        Text("Terminal", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Embedded Python command console", color = muted, fontSize = 11.sp)
        Spacer(Modifier.height(10.dp))
        GlassPanel(Modifier.weight(1f).fillMaxWidth(), panel, edge) {
            Text(output, color = Color(0xFF9DDBB0), fontFamily = FontFamily.Monospace, fontSize = 11.sp, lineHeight = 17.sp, modifier = Modifier.weight(1f).verticalScroll(rememberScrollState()))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$", color = Color(0xFF8FB5FF), fontFamily = FontFamily.Monospace)
                Spacer(Modifier.width(8.dp))
                BasicTextField(command, onCommand, Modifier.weight(1f), textStyle = TextStyle(color = fg, fontFamily = FontFamily.Monospace, fontSize = 12.sp), cursorBrush = SolidColor(fg), singleLine = true)
                IconButton(onClick = { onExecute(command) }, enabled = !busy) { Icon(Icons.Default.Send, null, tint = fg) }
            }
        }
    }
}

@Composable
private fun ColumnScope.ProjectsScreen(fg: Color, muted: Color, panel: Color, edge: Color, onOpen: () -> Unit, onSave: () -> Unit) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Projects & files", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Use Android's document picker to work with files in shared storage.", color = muted, fontSize = 12.sp)
        MenuItem(Icons.Default.FolderOpen, "Open Python file", "Import a .py file from your phone", fg, muted, panel, edge, onOpen)
        MenuItem(Icons.Default.Save, "Export current file", "Save editor contents to shared storage", fg, muted, panel, edge, onSave)
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("Workspace roadmap", color = fg, fontWeight = FontWeight.SemiBold)
            Text("Persistent project folders, multi-file explorer, rename, move, search and project-specific environments are planned for the next workspace milestone.", color = muted, fontSize = 12.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun ColumnScope.PackagesScreen(packageInfo: String, fg: Color, muted: Color, panel: Color, edge: Color, onRefresh: () -> Unit) {
    Column(Modifier.weight(1f)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Package Hub", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = fg) }
        }
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("Installed packages", color = fg, fontWeight = FontWeight.SemiBold)
            Text("Refresh reads package metadata from the embedded Python runtime.", color = muted, fontSize = 11.sp)
            Spacer(Modifier.height(10.dp))
            Text(packageInfo, color = fg, fontSize = 11.sp, lineHeight = 17.sp, fontFamily = FontFamily.Monospace)
        }
        Spacer(Modifier.height(10.dp))
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("Package installation status", color = fg, fontWeight = FontWeight.SemiBold)
            Text("This build supports package inspection. Dynamic pip installation is not yet enabled: Chaquopy packages are currently bundled at APK build time and must have Android-compatible wheels. The next runtime milestone will add a curated wheel repository and install manager.", color = muted, fontSize = 12.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun ColumnScope.MusicScreen(source: String, fg: Color, muted: Color, panel: Color, edge: Color, onPick: () -> Unit, onPause: () -> Unit, onResume: () -> Unit, onStop: () -> Unit) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Music Studio", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Icon(Icons.Default.Album, null, tint = Color(0xFF9CB8F5), modifier = Modifier.size(48.dp))
            Text(if (source.isBlank()) "Nothing playing" else "Audio source loaded", color = fg, fontWeight = FontWeight.SemiBold)
            Text(if (source.startsWith("content://")) "Local audio file" else if (source.isBlank()) "Choose a local audio file or direct audio stream." else "Direct stream", color = muted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPick) { Text("Choose audio") }
                OutlinedButton(onClick = onPause) { Text("Pause") }
                OutlinedButton(onClick = onResume) { Text("Resume") }
                OutlinedButton(onClick = onStop) { Text("Stop") }
            }
        }
        Text("Playback runs through an Android foreground media service with notification controls. YouTube background playback is not implemented; use supported YouTube playback or local/direct audio sources.", color = muted, fontSize = 12.sp, lineHeight = 19.sp)
    }
}

@Composable
private fun ColumnScope.ToolsScreen(fg: Color, muted: Color, panel: Color, edge: Color) {
    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("Developer toolkit", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("These commands run in the embedded Python workspace. Open Terminal to use them.", color = muted, fontSize = 11.sp)
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("Available now", color = Color(0xFF54B982), fontWeight = FontWeight.SemiBold)
            listOf(
                "Workspace files" to "pwd · ls · cd · mkdir · touch · cat · cp · mv · rm",
                "Python runtime" to "Persistent CPython session · run editor buffer · run workspace files",
                "Package inspection" to "pip list · pip show (inspection only)",
                "API requests" to "http GET|POST|PUT|PATCH|DELETE|HEAD URL [JSON]",
                "Data tools" to "json FILE · json-check FILE · xml FILE · sqlite FILE SQL",
                "Workspace search" to "tree [PATH] · find TEXT [PATH] · check FILE",
                "Archives" to "zip FILE PATH... · unzip FILE [DEST]",
                "Diagnostics" to "sysinfo · env · sys.path",
                "Audio" to "Local audio/direct streams · background notification controls"
            ).forEach { (label, detail) ->
                Spacer(Modifier.height(8.dp))
                Text(label, color = fg, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                Text(detail, color = muted, fontSize = 11.sp, lineHeight = 16.sp)
            }
        }
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("Advanced integrations still outstanding", color = Color(0xFFE1A65A), fontWeight = FontWeight.SemiBold)
            Text(
                "Full Linux/bash userspace and apt/pkg · dynamic pip install/uninstall and virtualenvs · Git client · Jupyter UI · graphical debugger/breakpoints · syntax-aware autocomplete/minimap/code folding · WebSocket client · local server manager · Black/Ruff/Mypy integration · offline docs · plugin marketplace · AI assistant · scheduled jobs · YouTube playback integration.",
                color = muted, fontSize = 12.sp, lineHeight = 19.sp
            )
            Text(
                "These need additional native/runtime integrations and are not represented as working controls. Android compatibility also limits native Python wheels.",
                color = muted, fontSize = 11.sp, lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun ColumnScope.SettingsScreen(theme: ThemeChoice, onTheme: (ThemeChoice) -> Unit, fg: Color, muted: Color, panel: Color, edge: Color) {
    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Appearance", color = fg, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("Theme", color = fg, fontWeight = FontWeight.SemiBold)
            Text("Choose your preferred appearance.", color = muted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(ThemeChoice.DARK, ThemeChoice.LIGHT, ThemeChoice.SYSTEM).forEach {
                    FilterChip(selected = theme == it, onClick = { onTheme(it) }, label = { Text(it.name.lowercase().replaceFirstChar(Char::uppercase)) })
                }
            }
        }
        GlassPanel(Modifier.fillMaxWidth(), panel, edge) {
            Text("AyaPy 3.0 · Python 3.13 · ARM64", color = fg, fontWeight = FontWeight.SemiBold)
            Text("Liquid Glass interface · Embedded CPython · Android native media service", color = muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun NavigationBar(screen: Screen, fg: Color, muted: Color, panel: Color, edge: Color, onSelect: (Screen) -> Unit) {
    val items = listOf(Screen.HOME to Icons.Default.Home, Screen.EDITOR to Icons.Default.Code, Screen.TERMINAL to Icons.Default.Terminal, Screen.PACKAGES to Icons.Default.Inventory2, Screen.MUSIC to Icons.Default.MusicNote)
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(panel).border(1.dp, edge, RoundedCornerShape(18.dp)).padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        items.forEach { (target, icon) ->
            IconButton(onClick = { onSelect(target) }) {
                Icon(icon, contentDescription = target.name, tint = if (screen == target) Color(0xFF8DB3FF) else muted)
            }
        }
    }
}
