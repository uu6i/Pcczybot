"""
AyaPy runtime services.

Persistent CPython namespace, workspace file operations, package inspection,
HTTP client, SQLite helpers, ZIP utilities and environment diagnostics.
The Android build embeds CPython; this is not a full Linux distribution.
"""
import contextlib
import io
import os
import sys
import traceback
import runpy
import importlib.metadata
import pathlib
import shlex
import sqlite3
import urllib.request
import urllib.error
import json
import zipfile
import shutil
import platform
import time
import ast
import xml.dom.minidom

_NAMESPACE = {"__name__": "__main__"}
_WORKSPACE = os.path.join(os.path.dirname(__file__), "workspace")
os.makedirs(_WORKSPACE, exist_ok=True)
os.chdir(_WORKSPACE)
if _WORKSPACE not in sys.path:
    sys.path.insert(0, _WORKSPACE)

def _safe_path(value):
    p = pathlib.Path(value or ".")
    p = (pathlib.Path(_WORKSPACE) / p).resolve() if not p.is_absolute() else p.resolve()
    if p != pathlib.Path(_WORKSPACE).resolve() and pathlib.Path(_WORKSPACE).resolve() not in p.parents:
        raise ValueError("Path must stay inside AyaPy workspace")
    return str(p)

def execute(source: str, reset: bool = False) -> str:
    global _NAMESPACE
    if reset:
        _NAMESPACE = {"__name__": "__main__"}
    output = io.StringIO()
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            exec(compile(source, "<ayapy-console>", "exec"), _NAMESPACE, _NAMESPACE)
    except SystemExit as exc:
        output.write(f"\nProcess exited: {exc}\n")
    except BaseException:
        traceback.print_exc(file=output)
    result = output.getvalue()
    return result if result else "(No output)"

def run_file(path: str) -> str:
    path = _safe_path(path)
    output = io.StringIO()
    try:
        with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
            runpy.run_path(path, run_name="__main__")
    except BaseException:
        traceback.print_exc(file=output)
    result = output.getvalue()
    return result if result else "(Program finished with no output)"

def package_list() -> str:
    rows = sorted((d.metadata.get("Name", d.name), d.version) for d in importlib.metadata.distributions())
    return "\n".join(f"{name}=={version}" for name, version in rows) or "(No third-party packages installed)"

def package_show(name: str) -> str:
    try:
        d = importlib.metadata.distribution(name)
        return f"{d.metadata.get('Name', name)} {d.version}\n{d.metadata.get('Summary', '')}"
    except importlib.metadata.PackageNotFoundError:
        return f"Package not installed: {name}"

def reset_namespace():
    global _NAMESPACE
    _NAMESPACE = {"__name__": "__main__"}
    return "Python session reset."

def workspace_info():
    return _WORKSPACE

def dispatch(command: str) -> str:
    """Small built-in command layer; commands run in the app's private workspace."""
    try:
        parts = shlex.split(command)
        if not parts:
            return ""
        op, args = parts[0], parts[1:]
        if op in ("help", "?"):
            return """AyaPy commands
python --version | python -c "code" | python FILE.py
pip list | pip show PACKAGE
pwd | ls [PATH] | cd PATH
mkdir NAME | touch FILE | cat FILE | rm FILE
cp SOURCE DEST | mv SOURCE DEST
env | sysinfo | sys.path
http GET|POST|PUT|DELETE URL [JSON]
sqlite FILE "SQL" | zip FILE PATH... | unzip FILE [DEST]
json FILE | json-check FILE | xml FILE | tree [PATH] | find TEXT [PATH]
clear | reset
Note: Android embedded CPython is not a complete Linux shell. Runtime pip installs,
Git, arbitrary bash commands and desktop wheels are not provided by this runtime."""
        if op == "pwd": return _WORKSPACE
        if op == "ls":
            target = _safe_path(args[0] if args else ".")
            return "\n".join(sorted(os.listdir(target))) or "(empty)"
        if op == "cd":
            target = _safe_path(args[0] if args else ".")
            if not os.path.isdir(target): return "Not a directory"
            os.chdir(target); return os.getcwd()
        if op == "mkdir":
            os.makedirs(_safe_path(args[0]), exist_ok=True); return "Directory created"
        if op == "touch":
            pathlib.Path(_safe_path(args[0])).touch(); return "File created"
        if op == "cat":
            return pathlib.Path(_safe_path(args[0])).read_text(errors="replace")
        if op == "rm":
            target = _safe_path(args[0])
            shutil.rmtree(target) if os.path.isdir(target) else os.remove(target)
            return "Removed"
        if op in ("cp", "mv"):
            src, dst = map(_safe_path, args[:2])
            shutil.copy2(src, dst) if op == "cp" else shutil.move(src, dst)
            return "Done"
        if op == "env":
            return "\n".join(f"{k}={v}" for k, v in sorted(os.environ.items()))
        if op == "sys.path": return "\n".join(sys.path)
        if op == "sysinfo":
            return f"Python {sys.version}\nPlatform: {platform.platform()}\nMachine: {platform.machine()}\nWorkspace: {_WORKSPACE}"
        if op == "http":
            method, url = args[0].upper(), args[1]
            if method not in {"GET", "POST", "PUT", "DELETE", "PATCH", "HEAD"}:
                return "Supported methods: GET POST PUT PATCH DELETE HEAD"
            payload = " ".join(args[2:]) if len(args) > 2 else None
            data = payload.encode("utf-8") if payload is not None and method not in {"GET", "HEAD"} else None
            req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type":"application/json","Accept":"application/json, text/*, */*","User-Agent":"AyaPy/4"})
            try:
                with urllib.request.urlopen(req, timeout=25) as response:
                    body = response.read(1_000_000).decode("utf-8", "replace") if method != "HEAD" else ""
                    return f"HTTP {response.status} {response.reason}\n{body}"
            except urllib.error.HTTPError as e:
                return f"HTTP {e.code} {e.reason}\n{e.read(100000).decode('utf-8','replace')}"
            except Exception as exc:
                return f"Request failed: {type(exc).__name__}: {exc}"
        if op == "json":
            path = _safe_path(args[0])
            return json.dumps(json.loads(pathlib.Path(path).read_text()), indent=2, ensure_ascii=False)
        if op == "json-check":
            path = _safe_path(args[0])
            json.loads(pathlib.Path(path).read_text())
            return "Valid JSON"
        if op == "xml":
            path = _safe_path(args[0])
            parsed = xml.dom.minidom.parse(path)
            return parsed.toprettyxml(indent="  ")
        if op == "tree":
            root = _safe_path(args[0] if args else ".")
            rows = []
            for base, dirs, files in os.walk(root):
                dirs[:] = sorted(d for d in dirs if d not in {".git", "__pycache__"})
                depth = pathlib.Path(base).relative_to(root).parts
                if len(depth) > 4:
                    dirs[:] = []
                    continue
                prefix = "  " * len(depth)
                rows.append(f"{prefix}{pathlib.Path(base).name or root}/")
                for filename in sorted(files):
                    rows.append(f"{prefix}  {filename}")
                if len(rows) > 500:
                    rows.append("... output truncated at 500 entries")
                    break
            return "\n".join(rows)
        if op == "find":
            needle = " ".join(args[:-1]) if len(args) > 1 else args[0]
            root = _safe_path(args[-1]) if len(args) > 1 else _WORKSPACE
            hits = []
            for base, dirs, files in os.walk(root):
                dirs[:] = [d for d in dirs if d not in {".git", "__pycache__"}]
                for filename in files:
                    full = os.path.join(base, filename)
                    try:
                        with open(full, encoding="utf-8") as handle:
                            for line_no, line in enumerate(handle, 1):
                                if needle in line:
                                    hits.append(f"{os.path.relpath(full, root)}:{line_no}: {line.rstrip()}")
                                    if len(hits) >= 200:
                                        return "\n".join(hits + ["... results capped at 200"])
                    except (UnicodeError, OSError):
                        continue
            return "\n".join(hits) if hits else "No matches"
        if op == "check":
            path = _safe_path(args[0])
            source = pathlib.Path(path).read_text(encoding="utf-8")
            ast.parse(source, filename=path)
            return "Syntax OK"
        if op == "sqlite":
            db = sqlite3.connect(_safe_path(args[0]))
            try:
                cur = db.execute(" ".join(args[1:]))
                rows = cur.fetchall()
                return json.dumps(rows, indent=2, default=str)
            finally: db.close()
        if op == "zip":
            with zipfile.ZipFile(_safe_path(args[0]), "w", zipfile.ZIP_DEFLATED) as z:
                for item in args[1:]:
                    path = _safe_path(item)
                    if os.path.isfile(path): z.write(path, os.path.relpath(path, _WORKSPACE))
                    else:
                        for base, _, files in os.walk(path):
                            for name in files:
                                full = os.path.join(base, name)
                                z.write(full, os.path.relpath(full, _WORKSPACE))
            return "Archive created"
        if op == "unzip":
            archive = _safe_path(args[0]); dest = _safe_path(args[1] if len(args)>1 else ".")
            with zipfile.ZipFile(archive) as z:
                for name in z.namelist(): _safe_path(os.path.join(os.path.relpath(dest,_WORKSPACE),name))
                z.extractall(dest)
            return "Archive extracted"
        return "Unknown command. Type help."
    except Exception as exc:
        return f"{type(exc).__name__}: {exc}"
